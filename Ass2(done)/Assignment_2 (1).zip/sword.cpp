#ifndef _definition_h_
#include "defs.h"
#define _definition_h_
#endif

report*  walkthrough (knight& theKnight, castle arrCastle[], int nCastle, int mode, int nPetal)
{
  report* pReturn;
  int bFlag;
  //fighting for the existence of mankind here
  
  
  // success or failure?	
  pReturn = (bFlag)? new report : NULL;
  return pReturn;
}